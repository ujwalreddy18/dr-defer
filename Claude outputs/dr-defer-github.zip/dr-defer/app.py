"""DR-Defer: diabetic retinopathy grading with deferral to a specialist.

Research prototype - NOT a medical device.

Pipeline is identical to the training/evaluation notebooks:
  crop black border -> pad to square -> resize 512 -> JPEG q92 -> resize 384
  -> ImageNet normalise -> EfficientNet-B0 -> softmax(logits / T)
Deferral rule: defer when (1 - max probability) > TAU.
"""
import os

import cv2
import gradio as gr
import numpy as np
import timm
import torch
import torch.nn.functional as F
import torchvision.transforms as T
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
WEIGHTS = os.path.join(HERE, "best.pt")

TEMPERATURE = 1.85      # fitted on EyePACS validation (notebook 02)
TAU = 0.540             # defer when 1 - max prob > TAU, i.e. confidence < 0.46
STAGES = ["0 - No DR", "1 - Mild", "2 - Moderate", "3 - Severe", "4 - Proliferative"]

device = "cuda" if torch.cuda.is_available() else "cpu"
model = timm.create_model("efficientnet_b0", pretrained=False, num_classes=5)
model.load_state_dict(torch.load(WEIGHTS, map_location="cpu"))
model.to(device).eval()

tf = T.Compose([
    T.Resize((384, 384)),
    T.ToTensor(),
    T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


def crop_resize(arr, size=512):
    mask = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY) > 10
    if mask.mean() > 0.1:
        ys, xs = np.where(mask)
        arr = arr[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = arr.shape[:2]
    s = max(h, w)
    canvas = np.zeros((s, s, 3), np.uint8)
    canvas[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = arr
    return cv2.resize(canvas, (size, size), interpolation=cv2.INTER_AREA)


def preprocess(pil_img):
    arr = np.array(pil_img.convert("RGB"))
    arr = crop_resize(arr)
    _, buf = cv2.imencode(".jpg", cv2.cvtColor(arr, cv2.COLOR_RGB2BGR),
                          [cv2.IMWRITE_JPEG_QUALITY, 92])
    arr = cv2.cvtColor(cv2.imdecode(buf, 1), cv2.COLOR_BGR2RGB)
    pil = Image.fromarray(arr).resize((384, 384))
    return pil, tf(pil).unsqueeze(0)


def gradcam(x):
    with torch.enable_grad():
        feats = model.forward_features(x.to(device))
        feats.retain_grad()
        logits = model.forward_head(feats)
        c = int(logits.argmax(1))
        model.zero_grad()
        logits[0, c].backward()
        w = feats.grad.mean(dim=(2, 3), keepdim=True)
        cam = F.relu((w * feats).sum(1, keepdim=True))
        cam = F.interpolate(cam, size=(384, 384), mode="bilinear", align_corners=False)
    cam = cam[0, 0].detach().cpu().numpy()
    return cam / (cam.max() + 1e-8)


def overlay(pil, cam):
    retina = np.asarray(pil.convert("L")) > 10
    cam = cam * retina
    heat = cv2.applyColorMap((cam * 255).astype(np.uint8), cv2.COLORMAP_JET)
    heat = cv2.cvtColor(heat, cv2.COLOR_BGR2RGB)
    base = np.asarray(pil).astype(np.float32)
    a = (0.4 * (cam > 0.05))[..., None]
    return Image.fromarray((base * (1 - a) + heat * a).astype(np.uint8))


def banner(text, colour):
    return (f"<div style='padding:14px 18px;border-radius:10px;background:{colour};"
            f"color:white;font-size:18px;font-weight:600'>{text}</div>")


def analyse(img):
    if img is None:
        return banner("Upload a retinal fundus image to begin.", "#6b7280"), None, None, ""

    pil, x = preprocess(img)
    with torch.no_grad():
        p = torch.softmax(model(x.to(device)) / TEMPERATURE, 1)[0].cpu().numpy()
    pred, conf = int(p.argmax()), float(p.max())
    defer = (1 - conf) > TAU

    rgb = np.asarray(pil).astype(np.float32)
    on_retina = rgb.mean(2) > 10
    retina_share = float(on_retina.mean())
    # Fundus photos are strongly red/orange: red channel well above blue.
    red_ratio = float(rgb[..., 0][on_retina].mean() / (rgb[..., 2][on_retina].mean() + 1)) \
        if on_retina.any() else 0.0
    warn = ""
    if retina_share < 0.35 or red_ratio < 1.5:
        warn = ("<p style='color:#b45309'><b>Warning:</b> this does not look like a standard "
                "fundus photo. The result is unreliable: the model will still output a "
                "grade for any image, so confidence cannot catch this.</p>")

    if defer:
        head = banner(f"DEFER: refer to a specialist (confidence {conf:.0%})", "#b45309")
        note = ("The model is not confident enough to grade this image on its own. "
                "A human specialist should review it.")
    else:
        head = banner(f"Auto-graded: {STAGES[pred]} (confidence {conf:.0%})", "#15803d")
        note = ("Referable DR (stage 2 or higher): refer for specialist assessment."
                if pred >= 2 else "No referable DR detected by the model (stage 0-1).")

    cam_img = overlay(pil, gradcam(x)) if pred != 0 else pil
    caption = ("Grad-CAM: regions that most influenced the predicted stage."
               if pred != 0 else "Stage 0 predicted: no lesion heatmap to show.")
    details = (f"{warn}<p>{note}</p><p style='font-size:13px;color:#6b7280'>{caption}<br>"
               f"Deferral threshold: confidence below {1 - TAU:.2f}. "
               "Research prototype for a capstone project. Not a medical device and not "
               "for clinical use. It grades severity in patients who already have diabetes; "
               "it does not detect diabetes.</p>")
    probs = {STAGES[i]: float(p[i]) for i in range(5)}
    return head, probs, cam_img, details


with gr.Blocks(title="DR-Defer") as demo:
    gr.Markdown("# DR-Defer\nDiabetic retinopathy grading that defers uncertain cases "
                "to a specialist.")
    with gr.Row():
        with gr.Column():
            inp = gr.Image(type="pil", label="Retinal fundus image")
            btn = gr.Button("Analyse", variant="primary")
        with gr.Column():
            verdict = gr.HTML()
            probs = gr.Label(num_top_classes=5, label="Stage probabilities")
            cam = gr.Image(label="Where the model looked", interactive=False)
            info = gr.HTML()
    btn.click(analyse, inp, [verdict, probs, cam, info])
    inp.change(analyse, inp, [verdict, probs, cam, info])

if __name__ == "__main__":
    demo.launch()
