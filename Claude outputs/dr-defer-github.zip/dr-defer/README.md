# DR-Defer: An Uncertainty-Aware and Explainable EfficientNet Ensemble Framework for Reliable Diabetic Retinopathy Grading

Capstone project, School of Computer Science and Artificial Intelligence, SR University, Warangal (Team 219).

Team: K. Ujwal Reddy (2303A51058), J. Sreeja (2303A51056), G. Varshitha Reddy (2303A51053).
Guide: Mr. P. Radhakrishnan, Assistant Professor, School of CS&AI.

DR-Defer grades diabetic retinopathy (stages 0 to 4) from a retinal fundus photograph of a patient who already has diabetes. It does not detect diabetes. A deferral layer withholds low-confidence cases so that a specialist can review them. Grad-CAM heat maps explain each grade.

**Research use only. Not a medical device.**

Live demo: https://huggingface.co/spaces/ujwalreddy18/dr-defer

## Key results (held-out EyePACS test set)
- Ensemble of three EfficientNet-B0 networks at 512 px: accuracy 0.666, QWK 0.749, ECE 0.033.
- Deferral grades 80.5% of cases automatically at accuracy 0.726 and QWK 0.815.
- Referable DR (stage 2 or higher): AUC 0.925, sensitivity 78.0%, specificity 90.2%.
- External APTOS 2019: accuracy 0.642, QWK 0.863; the threshold does not transfer unchanged.

## Repository layout
```
engine.py, server.py, app.py   inference engine, FastAPI server, Hugging Face entry point
best_512_s0.pt ... s2.pt       trained weights (three seeds)
static/index.html              single-page web front end
notebooks/                     training (3 seeds), analysis, final evaluation, XAI comparison
requirements.txt
```

## Run locally
```
python -m venv venv
venv\Scripts\activate        # Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
python server.py
```
The browser opens http://127.0.0.1:8000. Images are processed in memory and never saved.

## Data
The models were trained on a subset of the Kaggle EyePACS Diabetic Retinopathy Detection data and tested on it and on APTOS 2019. The images are not included in this repository, because the competition terms do not allow redistribution. Download them from Kaggle to rerun the notebooks.

## Settings (top of engine.py)
TEMPS (per-model temperatures), TE (ensemble temperature), TAU = 0.5013 (defer when confidence is below about 0.4987).
